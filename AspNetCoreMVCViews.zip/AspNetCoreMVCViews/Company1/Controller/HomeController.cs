using Microsoft.AspNetCore.Mvc;
using Company.Models;
// using mvc.DemoApp1.Models;

namespace DemoApp1.Controllers;

public class HomeController(CompanyModel model) : Controller
{

    public IActionResult Index()
    {
        var Worker = model.GetAllEmployees();
        return View(Worker); 
    }

    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Register(decimal deptId, decimal empno, string name, string job, decimal mgr, DateTime date, decimal salary,decimal comm)
    {
        model.AcceptEmployees(deptId, empno, name, job, mgr, date, salary,comm);
        return RedirectToAction("Index");
        }

}