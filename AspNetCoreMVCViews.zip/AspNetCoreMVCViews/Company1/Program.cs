
using Company.Models;

//using var dept = new EmpDbContext();

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

builder.Services.AddScoped<CompanyModel>();
var app = builder.Build();
app.MapDefaultControllerRoute();
// app.MapGet("/", () => "Hello World!");

app.Run();