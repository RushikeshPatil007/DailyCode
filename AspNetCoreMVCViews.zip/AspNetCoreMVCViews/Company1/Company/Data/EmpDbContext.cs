using Microsoft.EntityFrameworkCore;

namespace Company.Data;

public class EmpDbContext : DbContext
{
    public DbSet<Department> Departments { get; set; }

     public DbSet<Employee> Employees { get; set; }
   

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Data Source=iitdac.met.edu;Database=Shop4;User Id=dac4;Password=Dac4@1234;Encrypt=False");
    }
}
