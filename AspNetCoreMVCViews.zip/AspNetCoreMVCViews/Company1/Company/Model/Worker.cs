namespace Company.Models;

public readonly record struct Worker(decimal EmployeeId, string Name, string Job,decimal salary ,decimal DeptNo);

