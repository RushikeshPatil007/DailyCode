using Company.Data;

namespace Company.Models;

public class CompanyModel
{
    // for all Employee models
    public IEnumerable<Worker> GetAllEmployees()
    {
        using var Emp = new EmpDbContext();
        var selection = from t in Emp.Employees
                        //where t.Id.Length > 0
                        select new Worker
                        {
                            EmployeeId = t.Id,
                            Name = t.Name,
                            Job = t.Job,
                            salary = t.Sal,
                            DeptNo = t.DepartmentId,
        
                        };
        return selection.ToList();
    }


    // insert a new Employee
    public void AcceptEmployees(decimal deptId, decimal empno, string name, string job, decimal mgr, DateTime date, decimal salary,decimal comm)
    {
        using var Emp = new EmpDbContext();
        var employee = Emp.Employees.Find(empno);
        if(employee is null)
        {
            employee = new Employee {Id = empno, Name = name, Job = job, mgr = mgr, HireDate = date, Sal = salary, Comm = comm };
            Emp.Employees.Add(employee);
        }
        //Employee.Departments.Add(new Department());
        employee.Name = name;
        Emp.SaveChanges();
    }

        

}