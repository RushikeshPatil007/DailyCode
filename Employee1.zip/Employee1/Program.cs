﻿using Microsoft.EntityFrameworkCore;
using Emp.Data;

using var shop=new ShopDbContext();

if(args.Length==0)
{
    foreach(var Employee in shop.Employees)
    
        Console.WriteLine($"{0,-8}{1,16:0.00}",Employee.Id,Employee.Salary);
    
}
else
{
    if (int.TryParse(args[0], out int employeeId))
    {
    var employee =shop.Employees
     .Where(c=> c.Id.ToString() == args[0])
     .Include(c=>c.Department)
     .FirstOrDefault();
     if(employee!=null)
   {
        Console.WriteLine($"Employee ID: {employee.Id}, Salary: {employee.Salary:0.00}");
        
        if (employee.Department != null) // Check if the department exists
        {
            Console.WriteLine($"Department ID: {employee.Department.Id}, Department Name: {employee.Department.Name}");
        }
        else
        {
            Console.WriteLine("No department associated with this employee.");
        }
    }
    else
    {
        Console.WriteLine("Employee not found.");
    }
} 
}
