
using Microsoft.EntityFrameworkCore;

namespace Emp.Data;

public class ShopDbContext : DbContext
{
    public DbSet<Employee> Employees { get; set; }
public DbSet<Department> Departments { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Data Source=iitdac.met.edu;Database=Shop4;User Id=dac4;Password=Dac4@1234;Encrypt=False");
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    modelBuilder.Entity<Employee>()
        .Property(e => e.Id) 
        .HasColumnType("int");   


        modelBuilder.Entity<Employee>()
                .HasOne(e => e.Department) 
                .WithMany(d => d.Employees) 
                .HasForeignKey(e => e.DepartmentId); 
}
}