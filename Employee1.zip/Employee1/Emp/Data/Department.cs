using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Emp.Data;


[Table("dept")]

public class Department
{
    [Key]
 [Column("DEPTNO")]

 public int Id{get;set;}

[Column("DNAME")]
 public String Name{get;set;}


  public List<Employee> Employees { get; set; } = new List<Employee>();
}