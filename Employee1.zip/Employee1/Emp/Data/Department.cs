using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Emp.Data;


[Table("DepartmentDetails")]

public class Department
{
    [Key]
 [Column("deptno")]

 public decimal Id{get;set;}

[Column("dname")]
 public string Name{get;set;}


  public List<Employee> Employees { get; set; } = new List<Employee>();
}