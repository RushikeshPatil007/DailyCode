using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Emp.Data;

[Table("emp69")]
public class Employee
{
    [Key]
[Column("EMPNO")]

public int Id{get;set;}
[Column("SAL")]
public decimal Salary{get;set;}
[Column("DEPTNO")]
public int DepartmentId{get;set;}

[ForeignKey("DEPTNO")]
        public Department Department { get; set; }
}
