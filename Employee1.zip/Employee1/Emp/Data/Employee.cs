using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Emp.Data;

[Table("EmployeDetails")]
public class Employee
{
    [Key]
[Column("empno")]

public int Id{get;set;}
[Column("sal")]
public decimal Salary{get;set;}
[Column("deptno")]
public decimal DepartmentId{get;set;}

[Column("deptno")]
        public Department Department { get; set; }
        

}
