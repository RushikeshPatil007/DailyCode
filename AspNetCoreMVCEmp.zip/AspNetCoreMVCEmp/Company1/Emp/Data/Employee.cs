using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Emp.Data;

[Table("EmployeDetails")]
public class Employee
{
    [Key]
[Column("empno")]
[DatabaseGenerated(DatabaseGeneratedOption.Identity)]

public int Id{get;set;}
[Column("sal")]
public decimal Salary{get;set;}
[Column("deptno")]
public decimal DepartmentId{get;set;}

[ForeignKey("DepartmentId")]
        public Department Department { get; set; }
        

}
