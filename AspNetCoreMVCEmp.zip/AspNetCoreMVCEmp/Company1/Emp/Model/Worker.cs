namespace Emp.Model;

public readonly record struct Worker(int Id,decimal Salary, decimal Deptno,string Dname);