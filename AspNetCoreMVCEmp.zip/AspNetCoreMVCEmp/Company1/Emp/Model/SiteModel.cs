using Emp.Data;
using Microsoft.EntityFrameworkCore;

namespace Emp.Model;

public class SiteModel
{
    public IEnumerable<Worker> GetWorkers()
    {
using var site = new ShopDbContext();
var selection = from t in site.Employees

select new Worker
{
 Id=t.Id,
 Salary=t.Salary,
 Deptno=t.DepartmentId,
 Dname=t.Department.Name
};
return selection.ToList();
    }

    public void AcceptWorker(int workerid, string loc)
    {
        using var site =new ShopDbContext();
        var workers = site.Employees
        .Include(e => e.Department)
        .FirstOrDefault(e=>e.Id==workerid);
        if(workers is null)
        {
            workers = new Employee{Id = workerid,Department=new Department{Name=loc}};
            site.Employees.Add(workers);
            
        }
        else 
        {
            if(workers.Department==null)
            {
                workers.Department=new Department{Name=loc};
            }
            else{
                workers.Department.Name=loc;            }
        
        site.SaveChanges();
    }
}
}