using Microsoft.AspNetCore.Mvc;

using Emp.Data;
using Emp.Model;

namespace Company.Controllers;

[ApiController]

public class SiteController : ControllerBase
{
[HttpGet("/api/site")]
public IActionResult ReadWorkers(SiteModel model)
{
var workers =model.GetWorkers();
if(workers.Any())
return Ok(workers);
return NotFound(); 
}

[HttpPost("/api/site")]
public IActionResult WriteWorkers(Employee input, SiteModel model)
{
    model.AcceptWorker(input.Id,input.Department.Name);
    return Ok();
}
}