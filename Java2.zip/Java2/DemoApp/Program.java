package DemoApp;
import java.util.Scanner;

import Bank.HomeLoan;
import Bank.PersonalLoan;

public class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the type of loan (Personal or Home):");
        String loanType = scanner.nextLine();

        System.out.println("Enter the principal amount:");
        double principal = scanner.nextDouble();

        System.out.println("Enter the period in years:");
        int period = scanner.nextInt();

        if (loanType.equalsIgnoreCase("Personal")) {
            PersonalLoan personalLoan = new PersonalLoan(principal, period);
            System.out.println("Interest Rate: " + personalLoan.getRate());
            System.out.println("Monthly EMI: " + personalLoan.GetEMI());

        } else if (loanType.equalsIgnoreCase("Home")) {
            HomeLoan homeLoan = new HomeLoan(principal, period);
            System.out.println("Interest Rate: " + homeLoan.getRate());
            System.out.println("Monthly EMI: " + homeLoan.GetEMI());

        } else {
            System.out.println("Invalid loan type. Please enter either 'Personal' or 'Home'.");
    }
    scanner.close();
}
}
