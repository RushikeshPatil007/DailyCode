package Bank;

public class HomeLoan extends Loan implements Discountable{
    private double principle;
    private int period;
    double rate;
    public HomeLoan(double principle, int period) {
        this.principle = principle;
        this.period = period;
    }

    public double GetPrinciple()
    {
        return principle;
    }

    public void SetPrinciple(double principle) {
        this.principle = principle;
    }

    public int GetPeriod() {
        return period;
    }

    public void SetPeriod(int period) {
        this.period = period;
    }

    @Override
    public double getRate(){
    
        if (principle <=500000 )
        return rate= 15;
        else 
        return rate=16;
    }

    @Override
    public double GetEMI(){
        double emi=principle *(1+getRate()*period/100)/(12*period);
        return emi;

    }

    @Override
    public double getDiscount(){
        return principle * 0.05;
    }
}
