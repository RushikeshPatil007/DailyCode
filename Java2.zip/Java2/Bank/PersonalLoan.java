package Bank;

public class PersonalLoan extends Loan implements Taxable{

    double principle;
    int period;
    double rate =0;

    public PersonalLoan(double principle, int period) {
        this.principle = principle;
        this.period = period;
    }

    public double GetPrinciple()
    {
        return principle;
    }   

    public void SetPrinciple(double principle) {
        this.principle = principle;
    }

    public int GetPeriod() {
        return period;
    }

    public void SetPeriod(int period) {
        this.period = period;
    }

    @Override
    public double getRate(){
        
        if (principle <=200000 )
        return rate= 10;
        else 
        return rate=11;
    }
    
    @Override
    public double GetEMI(){
        double emi=principle *(1+getRate()*period/100)/(12*period);
        return emi;

    }
    @Override
    public double getTax()
    {
        return principle * 0.1;
    }
}
