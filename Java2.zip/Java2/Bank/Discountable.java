package Bank;

public interface Discountable {
    public double getDiscount();
}
