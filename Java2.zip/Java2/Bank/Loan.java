package Bank;

public abstract class Loan{
    public abstract double getRate();
    public abstract double GetEMI();
}