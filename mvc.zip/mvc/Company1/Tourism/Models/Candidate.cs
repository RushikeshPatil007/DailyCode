namespace Tourism.Models;

public readonly record struct Candidate(decimal DeptId, string Dname , string Loc);
