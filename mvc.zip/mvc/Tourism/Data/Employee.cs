using System.ComponentModel.DataAnnotations.Schema;

namespace Employeedept.Data;
[Table("Employees45")]

public class Employee
{
    [Column("empno")]
    public decimal Id {get; set; }

    public string ename{ get; set; }
    
    public string job { get; set; }

    public decimal sal { get; set; }

    [Column("deptno")]
    public decimal DepartmentId {get; set; }



}