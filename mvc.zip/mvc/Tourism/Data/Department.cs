using System.ComponentModel.DataAnnotations.Schema;

namespace Employeedept.Data;

[Table("Department45")]
public class Department
{

    [Column("deptno")]
    public decimal Id { get; set; }

    public string dname { get; set; }

    [Column("loc")]
    public string location { get; set; }

    public List<Employee> Employees { get; set; }
}