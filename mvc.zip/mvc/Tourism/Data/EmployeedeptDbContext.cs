using Microsoft.EntityFrameworkCore;

namespace Employeedept.Data;

public class EmployeedeptDbContext : DbContext
{

    public DbSet<Department> Departments { get; set; }

    public EmployeedeptDbContext()
    
    {
      Database.EnsureCreated();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsdBuilder)
     {

        optionsdBuilder.UseSqlServer("Data Source=iitdac.met.edu;Database=Shop2;User Id=dac2;Password=Dac2@1234;Encrypt=False");
     }
}